// const buffer = Buffer.alloc(8);
// buffer.write("Aa");
// console.log(buffer);
// console.log(buffer.toString());

// const buffer = Buffer.from("string", "utf-8");



// const buffer = Buffer.alloc(300, 10);
// console.log(buffer);



// const buffer = Buffer.from("string", "utf-8");
// console.log(String.fromCharCode(buffer[0]));


// const fs = require("fs");
// try {
//     const data = fs.readFileSync("data.txt", "utf8";
//     console.log(data);)
// } catch (err) {
//     console.error(err);
// }

import fs from 'fs';
fs.readFile ("events.js", "utf8", (err, data) => {
    if (err) {
        console.error(err);
    } else {
        console.log(data);
    }
}); 

