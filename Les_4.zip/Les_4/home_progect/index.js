// Імпортуємо необхідні модулі
import { promises as fs } from 'fs';
import path from 'path';

// Визначаємо шлях до файлу
const filePath = path.resolve('sample.txt');

/**
 * Завдання 1: Читання файлу та виведення статистики
 * - Кількість літер у файлі
 * - Кількість пробілів
 * - Кількість рядків
 */
async function taskOne() {
  try {
    // Читаємо вміст файлу у вигляді рядка
    const data = await fs.readFile(filePath, 'utf-8');

    // Регулярний вираз для пошуку літер (як великих, так і малих)
    const letters = data.match(/[a-zA-Zа-яА-ЯёЁіІїЇєЄ]/g) || [];
    const letterCount = letters.length;

    // Регулярний вираз для пошуку пробілів
    const spaces = data.match(/\s/g) || [];
    const spaceCount = spaces.length;

    // Розбиваємо вміст за символом нового рядка та рахуємо кількість рядків
    const lines = data.split('\n');
    const lineCount = lines.length;

    console.log('--- Завдання 1: Статистика файлу ---');
    console.log(`Кількість літер: ${letterCount}`);
    console.log(`Кількість пробілів: ${spaceCount}`);
    console.log(`Кількість рядків: ${lineCount}\n`);
  } catch (error) {
    console.error('Помилка при виконанні Завдання 1:', error.message);
  }
}

/**
 * Завдання 2: Читання файлу та виведення змісту у зворотному порядку
 */
async function taskTwo() {
  try {
    // Читаємо вміст файлу
    const data = await fs.readFile(filePath, 'utf-8');

    // Розбиваємо вміст на окремі символи, перевертаємо та об'єднуємо назад у рядок
    const reversedData = data.split('').reverse().join('');

    console.log('--- Завдання 2: Зміст файлу у зворотному порядку ---');
    console.log(reversedData + '\n');
  } catch (error) {
    console.error('Помилка при виконанні Завдання 2:', error.message);
  }
}

/**
 * Завдання 3: Читання файлу та виведення кожного другого слова
 */
async function taskThree() {
  try {
    // Читаємо вміст файлу
    const data = await fs.readFile(filePath, 'utf-8');

    // Розбиваємо вміст на слова, використовуючи пробіли та символи нового рядка як розділювачі
    const words = data.split(/\s+/).filter(Boolean);

    // Вибираємо кожне друге слово (з індексом 1, 3, 5, ...)
    const everySecondWord = words.filter((_, index) => index % 2 === 1);

    console.log('--- Завдання 3: Кожне друге слово з файлу ---');
    console.log(everySecondWord.join(' ') + '\n');
  } catch (error) {
    console.error('Помилка при виконанні Завдання 3:', error.message);
  }
}

/**
 * Головна функція, яка викликає всі завдання послідовно
 */
async function main() {
  await taskOne();
  await taskTwo();
  await taskThree();
}

// Виконуємо головну функцію
main();
