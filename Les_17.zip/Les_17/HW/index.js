//@ts-check

/**
 *
 * @param {Number} a
 * @param {Number} b
 * @returns
 */
function add(a, b) {
  if (a > b) return (a = 22);
  else return (b = b - 7);
}

console.log(add(4, 5));
