import http from 'http';
import fetch from 'node-fetch';

// Створення HTTP сервера
const server = http.createServer(async (req, res) => {
  // Відповідь на GET-запит на кореневий шлях
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Hello, World!');
  }
  // Обробка POST-запиту на шлях "/data"
  else if (req.method === 'POST' && req.url === '/data') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(data));
      } catch (error) {
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid JSON');
      }
    });
  }
  // Проксі сервер для перенаправлення запитів
  else if (req.url.startsWith('/proxy')) {
    const targetUrl = 'https://jsonplaceholder.typicode.com/todos/1';
    try {
      const response = await fetch(targetUrl);
      const data = await response.json();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Error fetching data from API');
    }
  } 
  // Якщо маршрут не знайдено
  else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

// Слухаємо порт 3000
server.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
