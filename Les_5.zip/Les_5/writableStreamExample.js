import { Writable } from 'stream';

class MyWritableStream extends Writable {
  constructor(options) {
    super(options);
    this.setDefaultEncoding('utf8');
  }

  _write(chunk, encoding, callback) {
    console.log('Записуємо в потік:', chunk.toString());
    callback();
  }
}

// Експортуємо клас
export default MyWritableStream;


