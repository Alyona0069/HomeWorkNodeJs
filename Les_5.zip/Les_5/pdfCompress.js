import { createReadStream, createWriteStream } from 'fs';
import { extname, resolve } from 'path';
import { Transform } from 'stream';
import zlib from 'zlib';

async function compressPDF(filePath) {
  if (extname(filePath) !== '.pdf') {
    throw new Error('Файл не є PDF.');
  }

  const outputFilePath = resolve(filePath + '.gz');

  const readStream = createReadStream(filePath);
  const writeStream = createWriteStream(outputFilePath);
  const gzip = zlib.createGzip();

  const transformStream = new Transform({
    transform(chunk, encoding, callback) {
      console.log('Частина даних, що трансформується:', chunk.length, 'байт');
      callback(null, chunk);
    }
  });

  readStream
    .pipe(transformStream)
    .pipe(gzip)
    .pipe(writeStream)
    .on('finish', () => {
      console.log('Файл успішно стиснуто та записано до', outputFilePath);
    });
}

// Експортуємо функцію
export default compressPDF;
