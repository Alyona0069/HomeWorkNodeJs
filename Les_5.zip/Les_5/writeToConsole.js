function writeToConsole(...args) {
    args.forEach(arg => {
      if (Buffer.isBuffer(arg)) {
        process.stdout.write('Буфер: ');
      } else {
        process.stdout.write('Рядок: ');
      }
      process.stdout.write(arg + '\n');
    });
  }
  
  // Експортуємо функцію
  export default writeToConsole;
  