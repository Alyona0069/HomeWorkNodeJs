import MyWritableStream from './writableStreamExample.js';
import compressPDF from './pdfCompress.js';
import writeToConsole from './writeToConsole.js';

// Тестування MyWritableStream
const myStream = new MyWritableStream();
myStream.write('Привіт, це тестовий запис!\n');
myStream.end('Це кінець потоку.');

// Перевірка після завершення потоку
console.log('writableEnded після end:', myStream.writableEnded);

// Тестування функції стиснення PDF
compressPDF('sample.pdf').catch(console.error);

// Тестування функції для запису у консоль
writeToConsole('Привіт, світ!', Buffer.from('Це дані у буфері.'));
 
