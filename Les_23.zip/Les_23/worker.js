import { parentPort, workerData } from 'worker_threads';

const array = workerData;
const sum = array.reduce((acc, value) => acc + value, 0);

parentPort.postMessage(sum);
