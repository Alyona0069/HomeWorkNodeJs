import { parentPort } from 'worker_threads';

parentPort.on('message', (array) => {
  const sum = array.reduce((acc, val) => acc + val, 0);
  parentPort.postMessage(sum);
});


