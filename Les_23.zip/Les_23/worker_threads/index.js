import { Worker } from 'worker_threads';
import { performance } from 'perf_hooks';

const largeArray = Array.from({ length: 10_000_000 }, () => Math.floor(Math.random() * 100));
const midIndex = Math.floor(largeArray.length / 2);
const firstHalf = largeArray.slice(0, midIndex);
const secondHalf = largeArray.slice(midIndex);
const start = performance.now();
const worker = new Worker('./worker.js');

worker.postMessage(secondHalf);

const sumFirstHalf = firstHalf.reduce((acc, val) => acc + val, 0);

worker.on('message', (sumSecondHalf) => {
  const totalSum = sumFirstHalf + sumSecondHalf;
  const end = performance.now();

  console.log(`Сума масиву: ${totalSum}`);
  console.log(`Час виконання: ${end - start} мс`);
});
