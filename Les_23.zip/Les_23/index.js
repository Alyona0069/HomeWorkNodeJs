import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
if (isMainThread) {
    const largeArray = Array.from({ length: 1e7 }, () => Math.floor(Math.random() * 100));
    const startTime = Date.now();
    const worker = new Worker('./worker.js', { workerData: largeArray });
    worker.on('message', (sum) => {
        const endTime = Date.now();
        console.log(`Сума: ${sum}`);
        console.log(`Час виконання з worker_threads: ${endTime - startTime} мс`);
    });
    worker.on('error', (err) => {
        console.error('Worker error:', err);
    });
    worker.on('exit', (code) => {
        if (code !== 0) {
            console.error(`Worker завершив роботу з кодом ${code}`);
        }
    });
} else {
    const array = workerData;
    const sum = array.reduce((acc, value) => acc + value, 0);
    parentPort.postMessage(sum);
}

const largeArray = Array.from({ length: 1e7 }, () => Math.floor(Math.random() * 100));
const startTime = Date.now();
const sum = largeArray.reduce((acc, value) => acc + value, 0);
const endTime = Date.now();

console.log(`Сума: ${sum}`);
console.log(`Час виконання без worker_threads: ${endTime - startTime} мс`);


