// //@ts-check
// /**
//  * 
//  * @param {Number} a 
//  * @param {Number} b 
//  * @returns 
//  */

// function add (a, b) {
//     return a + b;
// }
// console.log(add(4, 5));